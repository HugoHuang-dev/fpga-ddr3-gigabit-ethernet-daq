# Project2 V7 上板验证完整操作步骤

## 1. 验证目标

本轮验证 V7 新增的 UART 控制面，并确认它没有破坏 V6 已闭环的 DDR3 环形缓存和 UDP 数据通路。完整顺序如下：

1. 初始状态与基础配置；
2. `START / STOP` 控制的 512 字节、25 Mword/s 连续传输；
3. 256、512、1024 字节动态包长；
4. `SET_RATE` 限速；
5. `FINITE` 有限长度自动停止；
6. 非法数据源、运行中改配置和错误 CRC 的保护行为；
7. 1024 字节、最大速率下的 60 秒筛选和 300 秒终验。

命令应答、最终状态、主机逐包校验和 FPGA 错误计数必须同时合格，V7 才算闭环。

## 2. 固定条件和文件

- FPGA IPv4：`192.168.1.11`
- 电脑 IPv4：`192.168.1.100`
- UDP 端口：`6666`
- UART：`COM4`、115200 baud、8N1、无流控
- 数据源：PRBS16，即 `source 0`
- 下载文件：`project2_v7_top.bit`
- 调试探针：`project2_v7_top.ltx`
- UART 工具：`v7_uart_control.py`
- 接收器：`udp_v7_monitor_rio.exe`

BIT 和 LTX 必须成对使用。串口号若发生变化，只替换命令中的 `COM4`。

所有命令均在以下目录执行：

```powershell
Set-Location "C:\Users\32035\Documents\Codex\2026-09-22\project2-fpga-thread-01a0bf53-7a53-74b0-2\outputs\project2_v7_uart_control\board_test_package"
New-Item -ItemType Directory -Force .\results | Out-Null
```

## 3. 两个窗口怎样配合

从首次数据测试开始，必须保留两个 PowerShell 窗口，并让它们都进入上述目录：

- **窗口 A：UART 命令窗口。** 输入 `status`、配置、`start`、`stop`。
- **窗口 B：UDP 接收窗口。** 只运行 `udp_v7_monitor_rio.exe`。

正确顺序始终是：

1. 在窗口 B 启动接收器；
2. 等窗口 B 出现 `ARMED: listening on 192.168.1.100:6666`；
3. 不关闭窗口 B，立即切到窗口 A；
4. 在窗口 A 输入 `start`。

接收器运行时会占用窗口 B，不能在窗口 B 输入 START。`ARMED` 表示接收器已经准备好、正在等第一包，并不是程序卡住。

## 4. 统一 PASS、证据和失败规则

### 4.1 数据测试的严格 PASS 条件

接收器必须打印：

```text
V7 UART-CONTROLLED STREAM TEST PASSED
```

对应 JSON 必须满足：

- `passed = true`，`packets_received > 0`
- `missing_packets = 0`，`gap_events = 0`
- `duplicates = 0`，`out_of_order = 0`
- `malformed = 0`，`metadata_errors = 0`
- `data_error_packets = 0`，`data_error_bytes = 0`
- `receive_completion_errors = 0`

每轮 STOP 并排空后的 UART `status` 还必须满足：

- `run_enable: False`，`fatal: False`
- `ingress_level_words: 0`，`occupancy_bytes: 0`
- ingress、ring、TX 的 overflow/underflow 全部为 `0`

限速测试有一个明确例外：当设定速率低于发送端约 400 Mb/s 的能力时，packetizer 会在等待下一完整包的空闲区间增加 `tx_underflow`。只要主机端包序、格式和 PRBS 全部正确，且其他内部错误为 0，该计数表示主动限速形成的饥饿区间，不判为数据错误。恢复最大速率并 `clear` 后，后续最终测试必须重新为 0。

### 4.2 失败后不要做什么

任意一轮出现 FAIL、超时、计数非零或状态异常时：

1. 不要立即重跑；
2. 不要重新下载 BIT、复位或断电；
3. 不要同时修改多个配置；
4. 先执行一次 `stop`，等待 500 ms，再执行 `status`；
5. 保存两个窗口完整截图和本轮 JSON；
6. 记录第一条异常，再只改变一个变量继续定位。

每轮使用下面指定的独立 JSON 文件名，禁止覆盖已有证据。

## 5. 阶段 0：下载与初始状态门禁

如果从已通过的基础测试后没有断电、按 RESET 或重新下载 BIT，可直接进入第 6 节。否则：

1. 在 Vivado Hardware Manager 中连接目标板；
2. Program Device 选择 `project2_v7_top.bit`；
3. Probes File 选择同目录的 `project2_v7_top.ltx`；
4. 下载后等待约 3 秒，让 DDR3 完成校准；
5. 在窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 1 status
```

必须看到 `result: OK`、`version: 7`、`run_enable: False`、`mig_calibrated: True`、`fatal: False`、`source: 0`，且所有错误计数为 0。

如果本次确实重新下载或复位过，还要在窗口 A 重新建立阶段 1 的基线配置：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 2 clear
py -3 .\v7_uart_control.py --port COM4 --seq 3 source 0
py -3 .\v7_uart_control.py --port COM4 --seq 4 rate 25000000
py -3 .\v7_uart_control.py --port COM4 --seq 5 packet-length 512
py -3 .\v7_uart_control.py --port COM4 --seq 6 mode continuous
```

五条命令都必须返回 `RESULT=OK`，然后再进入第 6 节。

### 当前已经完成的记录

真板已确认：初始 `READ_STATUS` 正常，`CLEAR_COUNTERS`、`source 0`、`rate 25000000`、`packet-length 512`、`mode continuous` 全部返回 OK。此前首包超时只是因为接收器占用了唯一窗口、未从第二个窗口发送 START，不是数据通路失败。

如果之后没有复位或重下载，不必重复配置，从下面开始即可。

## 6. 阶段 1：512 字节、25 Mword/s、continuous、60 秒

25,000,000 个 16 位字/秒对应约 400 Mb/s 有效载荷。

在窗口 B 执行：

```powershell
.\udp_v7_monitor_rio.exe --duration 60 --first-timeout 60 --output .\results\v7_gate1_512B_25M_60s.json
```

看到 `ARMED` 后，不要等窗口 B 返回提示符；切到窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 7 start
```

必须返回 `TYPE=0x83 SEQ=7 RESULT=OK`。让窗口 B 自动运行并完成 60 秒测试，然后在窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 8 stop
Start-Sleep -Milliseconds 500
py -3 .\v7_uart_control.py --port COM4 --seq 9 status
```

STOP 必须返回 `TYPE=0x84 SEQ=8 RESULT=OK`。接收结果和最终状态必须满足第 4.1 节。保存两个窗口截图和 `results\v7_gate1_512B_25M_60s.json`。

## 7. 阶段 2：动态包长 256 / 1024 字节

512 字节已由上一阶段覆盖。本阶段只改变包长，其余保持 25 Mword/s、continuous。

### 7.1 256 字节

确认上一轮已 STOP 并排空，在窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 10 clear
py -3 .\v7_uart_control.py --port COM4 --seq 11 packet-length 256
py -3 .\v7_uart_control.py --port COM4 --seq 12 rate 25000000
py -3 .\v7_uart_control.py --port COM4 --seq 13 mode continuous
```

四条都必须返回 OK。窗口 B 执行：

```powershell
.\udp_v7_monitor_rio.exe --duration 10 --first-timeout 60 --output .\results\v7_gate2_256B_25M_10s.json
```

看到 `ARMED` 后，窗口 A 执行 `start`：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 14 start
```

窗口 B 完成后，窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 15 stop
Start-Sleep -Milliseconds 500
py -3 .\v7_uart_control.py --port COM4 --seq 16 status
```

除统一 PASS 条件外，JSON 的 `udp_payload_bytes` 必须为 `256`。

### 7.2 1024 字节

上一轮状态合格后，窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 17 clear
py -3 .\v7_uart_control.py --port COM4 --seq 18 packet-length 1024
py -3 .\v7_uart_control.py --port COM4 --seq 19 rate 25000000
py -3 .\v7_uart_control.py --port COM4 --seq 20 mode continuous
```

窗口 B 执行：

```powershell
.\udp_v7_monitor_rio.exe --duration 10 --first-timeout 60 --output .\results\v7_gate2_1024B_25M_10s.json
```

看到 `ARMED` 后，窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 21 start
```

窗口 B 完成后，窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 22 stop
Start-Sleep -Milliseconds 500
py -3 .\v7_uart_control.py --port COM4 --seq 23 status
```

除统一 PASS 条件外，JSON 的 `udpayload_bytes` 必须为 `1024`。

## 8. 阶段 3：SET_RATE 限速验证

保持 1024 字节包长，将速率改为 12,500,000 个 16 位字/秒，对应约 200 Mb/s。

窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 24 clear
py -3 .\v7_uart_control.py --port COM4 --seq 25 packet-length 1024
py -3 .\v7_uart_control.py --port COM4 --seq 26 rate 12500000
py -3 .\v7_uart_control.py --port COM4 --seq 27 mode continuous
```

窗口 B 执行：

```powershell
.\udp_v7_monitor_rio.exe --duration 10 --first-timeout 60 --output .\results\v7_gate3_1024B_12M5_10s.json
```

看到 `ARMED` 后，窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 28 start
```

窗口 B 完成后，窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 29 stop
Start-Sleep -Milliseconds 500
py -3 .\v7_uart_control.py --port COM4 --seq 30 status
```

要求除上述主动限速允许的 `tx_underflow` 外，其余统一零错误条件成立；同时 `udp_payload_bytes = 1024`，status 中 `rate_words_per_sec: 12500000`。`payload_rate_mbps` 应接近 200，建议以 195–205 Mb/s 作为观测范围；略有偏差时先保留结果，不要擅自修改时钟参数。

## 9. 阶段 4：FINITE 有限长度自动停止

固定配置：256 字节、`rate 0`（最大速率）、finite 1,048,576 个 16 位字。总有效载荷为 2,097,152 字节，理论结果必须是 `2097152 / 256 = 8192` 包。

窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 31 clear
py -3 .\v7_uart_control.py --port COM4 --seq 32 packet-length 256
py -3 .\v7_uart_control.py --port COM4 --seq 33 rate 0
py -3 .\v7_uart_control.py --port COM4 --seq 34 mode finite 1048576
```

窗口 B 执行：

```powershell
.\udp_v7_monitor_rio.exe --duration 10 --first-timeout 60 --output .\results\v7_gate4_finite_1Mwords_256B.json
```

看到 `ARMED` 后，窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 35 start
```

FPGA 发完 finite 数据后会自动撤销运行使能；本轮不要手动 STOP。等窗口 B 自动结束，再在窗口 A 执行：

```powershell
Start-Sleep -Milliseconds 500
py -3 .\v7_uart_control.py --port COM4 --seq 36 status
```

JSON 除统一条件外，必须精确满足：

- `packets_received = 8192`
- `payload_bytes = 2097152`
- `udp_payload_bytes = 256`

最终 status 必须满足：

- `run_enable: False`，`finite_done: True`，`finite_mode: True`
- `finite_words: 1048576`，`run_words: 1048576`
- `packet_sequence: 8192`
- `ingress_level_words: 0`，`occupancy_bytes: 0`
- 所有数据通路错误计数为 0

包数或字节数不精确相等时，即使接收器打印 PASS，也不能把 finite 记为通过。

## 10. 阶段 5：命令保护与错误计数

本阶段不运行 UDP 接收器，只在窗口 A 操作。

### 10.1 清零和不支持的数据源

保存 finite 结果后执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 40 clear
py -3 .\v7_uart_control.py --port COM4 --seq 41 source 1
```

第二条预期返回：

```text
TYPE=0x90 SEQ=41 RESULT=UNSUPPORTED
```

数据源必须仍保持 `source: 0`。

### 10.2 运行中修改包长

设置低速连续模式，保证有时间发送下一条命令：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 42 rate 1000
py -3 .\v7_uart_control.py --port COM4 --seq 43 mode continuous
py -3 .\v7_uart_control.py --port COM4 --seq 44 start
py -3 .\v7_uart_control.py --port COM4 --seq 45 packet-length 256
```

前三条必须 OK，第四条必须返回：

```text
TYPE=0x92 SEQ=45 RESULT=BUSY
```

然后执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 46 stop
Start-Sleep -Milliseconds 500
```

### 10.3 错误 CRC 静默丢弃

执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 47 --corrupt-crc --expect-no-reply status
```

工具必须打印 `PASS: no reply received, as expected`。接着读取有效状态：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 48 status
```

重点检查：`run_enable: False`、`source: 0`、`uart_crc_errors: 1`、`command_rejects: 2`、`fatal: False`。1000 word/s 低速运行可能按第 4.1 节的定义产生少量 `tx_underflow`；其他数据通路错误必须为 0。两个 reject 分别来自 `source 1` 和运行中改包长；错误 CRC 只增加 `uart_crc_errors`。

### 10.4 恢复最终测试配置

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 49 source 0
py -3 .\v7_uart_control.py --port COM4 --seq 50 rate 0
py -3 .\v7_uart_control.py --port COM4 --seq 51 packet-length 1024
py -3 .\v7_uart_control.py --port COM4 --seq 52 mode continuous
py -3 .\v7_uart_control.py --port COM4 --seq 53 clear
```

全部必须返回 OK。保存本阶段完整窗口截图，作为 UART 错误处理证据。

## 11. 阶段 6：1024 字节最大速率 60 秒筛选

第 10.4 节已完成配置与清零。窗口 B 执行：

```powershell
.\udp_v7_monitor_rio.exe --duration 60 --first-timeout 60 --output .\results\v7_gate6_1024B_max_60s.json
```

看到 `ARMED` 后，窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 54 start
```

窗口 B 完成后，窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 55 stop
Start-Sleep -Milliseconds 500
py -3 .\v7_uart_control.py --port COM4 --seq 56 status
```

要求统一 PASS 条件成立且 `udp_payload_bytes = 1024`。`rate 0` 表示尽可能快，实际吞吐受链路反压影响；核心判据仍是无丢包、无乱序、PRBS 全正确、FPGA 错误计数全零。

## 12. 阶段 7：1024 字节最大速率 300 秒终验

只有 60 秒筛选通过后才执行。

窗口 A 复核配置并清零：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 60 source 0
py -3 .\v7_uart_control.py --port COM4 --seq 61 rate 0
py -3 .\v7_uart_control.py --port COM4 --seq 62 packet-length 1024
py -3 .\v7_uart_control.py --port COM4 --seq 63 mode continuous
py -3 .\v7_uart_control.py --port COM4 --seq 64 clear
```

窗口 B 执行：

```powershell
.\udp_v7_monitor_rio.exe --duration 300 --first-timeout 60 --output .\results\v7_gate7_1024B_max_300s.json
```

看到 `ARMED` 后，窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 65 start
```

运行中不要切换网络、启动其他高流量程序、复位 FPGA 或发送其他 UART 命令。窗口 B 完成后，窗口 A 执行：

```powershell
py -3 .\v7_uart_control.py --port COM4 --seq 66 stop
Start-Sleep -Milliseconds 500
py -3 .\v7_uart_control.py --port COM4 --seq 67 status
```

最终必须同时满足：接收器 PASS；JSON 持续约 300 秒且所有错误项为 0；`udp_payload_bytes = 1024`；STOP 后 FIFO 与 DDR 占用归零；FPGA overflow/underflow 全为 0；`fatal: False`、`uart_crc_errors: 0`、`command_rejects: 0`。

## 13. 整体验收表

| 阶段 | 核心配置 | 主要检查 | 当前状态 |
| --- | --- | --- | --- |
| 0 | 初始状态与基础 UART 配置 | DDR 校准、状态、命令 OK | 已通过并归档 |
| 1 | 512 B，25 Mword/s，60 s | START/STOP、严格零错误 | 已通过并归档 |
| 2A | 256 B，25 Mword/s，10 s | 动态包长、PRBS 连续性 | 已通过并归档 |
| 2B | 1024 B，25 Mword/s，10 s | 动态包长、PRBS 连续性 | 已通过并归档 |
| 3 | 1024 B，12.5 Mword/s，10 s | 约 200 Mb/s 限速 | 已通过并归档 |
| 4 | 256 B，finite 1,048,576 words | 8192 包、自动停止、精确计数 | 已通过并归档 |
| 5 | 非法 source、BUSY、错误 CRC | 拒绝码与诊断计数 | 已通过并归档 |
| 6 | 1024 B，最大速率，60 s | 高速筛选、严格零错误 | 已通过并归档 |
| 7 | 1024 B，最大速率，300 s | 最终稳定性闭环 | 已通过并归档 |

## 14. 最终证据清单

保留 `results` 下全部 JSON：

- `v7_gate1_512B_25M_60s.json`
- `v7_gate2_256B_25M_10s.json`
- `v7_gate2_1024B_25M_10s.json`
- `v7_gate3_1024B_12M5_10s.json`
- `v7_gate4_finite_1Mwords_256B.json`
- `v7_gate6_1024B_max_60s.json`
- `v7_gate7_1024B_max_300s.json`

每个数据阶段至少保留窗口 B 的 `FINAL` 与 PASS/FAIL、窗口 A 的 STOP 与最终 status。阶段 5 需保留 UNSUPPORTED、BUSY、错误 CRC 无应答和最终计数的完整截图。截图必须包含命令和完整输出。

V6 已完成数据通路 ILA 闭环。V7 正常通过时，以 UART 命令/应答、`READ_STATUS`、JSON 和截图为证据，不重复抓 V6 四组 ILA。只有数据阶段失败且现有证据不能区分入口、DDR 环形缓存或 TX 问题时，才使用匹配的 `project2_v7_top.ltx` 进入 ILA 定位；失败证据必须先保留。
